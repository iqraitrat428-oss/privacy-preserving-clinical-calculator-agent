param_full_name = {
    "feeling_nervous": ("feeling nervous, anxious, or on edge", None),
    "not_able_to_stop_worrying": ("not being able to stop or control worrying", None),
    "worrying_too_much": ("worrying too much about different things", None),
    "trouble_relaxing": ("trouble relaxing", None),
    "being_restless": ("being so restless it is hard to sit still", None),
    "easily_annoyed": ("becoming easily annoyed or irritable", None),
    "feeling_afraid": ("feeling afraid as if something awful might happen", None),
}

freq_map = {"not at all": 0, "several days": 1, "more than half the days": 2, "nearly every day": 3}


def gad7_explanation(input_parameters):
    explanation = """The GAD-7 (Generalized Anxiety Disorder-7) questionnaire:

Over the last 2 weeks, how often have you been bothered by:
1. Feeling nervous, anxious, or on edge (0-3)
2. Not being able to stop or control worrying (0-3)
3. Worrying too much about different things (0-3)
4. Trouble relaxing (0-3)
5. Being so restless that it is hard to sit still (0-3)
6. Becoming easily annoyed or irritable (0-3)
7. Feeling afraid as if something awful might happen (0-3)

Scoring: Not at all=0, Several days=1, More than half=2, Nearly every day=3
Total 0-4: Minimal anxiety, 5-9: Mild, 10-14: Moderate, 15-21: Severe
"""
    explanation += "\nThe patient's current GAD-7 score is 0.\n"
    score = 0
    for param, label in param_full_name.items():
        val = input_parameters.get(param, 0)
        val = val[0] if isinstance(val,(list,tuple)) else val
        if isinstance(val, str): val = freq_map.get(val.lower(), 0)
        explanation += f"{label[0].capitalize()}: {val} points, making the total {score} + {val} = {score+val}.\n"
        score += val
    explanation += f"The final GAD-7 score is {score}."
    return {"Explanation": explanation, "Answer": score}


def gad7(feeling_nervous=0, not_able_to_stop_worrying=0, worrying_too_much=0,
         trouble_relaxing=0, being_restless=0, easily_annoyed=0, feeling_afraid=0):
    def v(x):
        x = x[0] if isinstance(x,(list,tuple)) else x
        if isinstance(x,str): return freq_map.get(x.lower(),0)
        return x
    return v(feeling_nervous)+v(not_able_to_stop_worrying)+v(worrying_too_much)+v(trouble_relaxing)+v(being_restless)+v(easily_annoyed)+v(feeling_afraid)
