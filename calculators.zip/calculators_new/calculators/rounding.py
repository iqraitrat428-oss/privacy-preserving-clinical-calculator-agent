from math import log10, floor

def round_number(num):
    if num == 0:
        return 0

    sig_digits = -int(floor(log10(abs(num)))) + 5

    if abs(num) >= 1e-4:
        return round(num, 5)
    else:
        return round(num, sig_digits)