param_full_name = {
    "ph": ("pH", None),
    "paco2": ("PaCO2", None),
    "hco3": ("HCO3-", None),
    "sodium": ("sodium", None),
    "chloride": ("chloride", None),
    "albumin": ("albumin", None),
}


def arterial_blood_gas_explanation(input_parameters):
    explanation = """The Arterial Blood Gas (ABG) Analyzer evaluates acid-base disorders and calculates the corrected anion gap.

Steps:
1. Identify primary disorder (pH, PaCO2, HCO3-)
   - pH < 7.35: Acidosis
   - pH > 7.45: Alkalosis
   - PaCO2 > 45 with acidosis: Respiratory Acidosis
   - HCO3- < 22 with acidosis: Metabolic Acidosis
   - PaCO2 < 35 with alkalosis: Respiratory Alkalosis
   - HCO3- > 26 with alkalosis: Metabolic Alkalosis
2. Calculate Anion Gap = Na - Cl - HCO3
3. Calculate Corrected Anion Gap = AG + 2.5*(4.0 - Albumin)
"""
    ph = input_parameters["ph"][0] if isinstance(input_parameters["ph"],(list,tuple)) else input_parameters["ph"]
    paco2 = input_parameters["paco2"][0] if isinstance(input_parameters["paco2"],(list,tuple)) else input_parameters["paco2"]
    hco3 = input_parameters["hco3"][0] if isinstance(input_parameters["hco3"],(list,tuple)) else input_parameters["hco3"]
    na = input_parameters.get("sodium", [140])[0] if isinstance(input_parameters.get("sodium"),(list,tuple)) else input_parameters.get("sodium", 140)
    cl = input_parameters.get("chloride", [104])[0] if isinstance(input_parameters.get("chloride"),(list,tuple)) else input_parameters.get("chloride", 104)
    alb = input_parameters.get("albumin", [4.0])[0] if isinstance(input_parameters.get("albumin"),(list,tuple)) else input_parameters.get("albumin", 4.0)

    # Primary disorder
    if ph < 7.35:
        if paco2 > 45: disorder = "Respiratory Acidosis"
        elif hco3 < 22: disorder = "Metabolic Acidosis"
        else: disorder = "Acidosis (mixed)"
    elif ph > 7.45:
        if paco2 < 35: disorder = "Respiratory Alkalosis"
        elif hco3 > 26: disorder = "Metabolic Alkalosis"
        else: disorder = "Alkalosis (mixed)"
    else:
        disorder = "Normal pH (may be compensated or mixed)"

    ag = na - cl - hco3
    corr_ag = round(ag + 2.5*(4.0 - alb), 4)

    explanation += f"\nABG Values: pH={ph}, PaCO2={paco2} mmHg, HCO3-={hco3} mEq/L\n"
    explanation += f"Primary disorder: {disorder}\n"
    explanation += f"Anion Gap = {na} - {cl} - {hco3} = {ag} mEq/L\n"
    explanation += f"Albumin-corrected Anion Gap = {ag} + 2.5*(4.0 - {alb}) = {corr_ag} mEq/L\n"
    explanation += f"The albumin-corrected anion gap is {corr_ag} mEq/L."
    return {"Explanation": explanation, "Answer": corr_ag}


def arterial_blood_gas(ph, paco2, hco3, sodium=None, chloride=None, albumin=None):
    def v(x, default): return x[0] if isinstance(x,(list,tuple)) else (x if x is not None else default)
    na = v(sodium, 140); cl = v(chloride, 104); alb = v(albumin, 4.0)
    hco3_v = v(hco3, 24)
    ag = na - cl - hco3_v
    return round(ag + 2.5*(4.0 - alb), 4)
