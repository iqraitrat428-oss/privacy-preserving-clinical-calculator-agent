param_full_name = {
    "nausea_vomiting": "nausea/vomiting",
    "tremor": "tremor",
    "paroxysmal_sweats": "paroxysmal sweats",
    "anxiety": "anxiety",
    "agitation": "agitation",
    "tactile_disturbances": "tactile disturbances",
    "auditory_disturbances": "auditory disturbances",
    "visual_disturbances": "visual disturbances",
    "headache": "headache, fullness in head",
    "orientation": "orientation and clouding of sensorium",
}


def ciwa_ar_explanation(input_parameters):
    explanation = """The CIWA-Ar (Clinical Institute Withdrawal Assessment for Alcohol) criteria:

Items 1-9 are scored 0-7, Item 10 (orientation) is scored 0-4.
1. Nausea/vomiting (0-7)
2. Tremor (0-7)
3. Paroxysmal sweats (0-7)
4. Anxiety (0-7)
5. Agitation (0-7)
6. Tactile disturbances (0-7)
7. Auditory disturbances (0-7)
8. Visual disturbances (0-7)
9. Headache (0-7)
10. Orientation/clouding of sensorium (0-4)

Score ≤8: Mild, 9-14: Moderate, ≥15: Severe withdrawal.
"""
    explanation += "\nThe patient's current CIWA-Ar score is 0.\n"
    score = 0
    items = ["nausea_vomiting","tremor","paroxysmal_sweats","anxiety","agitation",
             "tactile_disturbances","auditory_disturbances","visual_disturbances","headache","orientation"]
    for item in items:
        val = input_parameters.get(item, 0)
        val = val[0] if isinstance(val,(list,tuple)) else val
        explanation += f"{param_full_name[item].capitalize()}: {val} points added, making the total {score} + {val} = {score + val}.\n"
        score += val
    explanation += f"The final CIWA-Ar score is {score}."
    return {"Explanation": explanation, "Answer": score}


def ciwa_ar(nausea_vomiting=0, tremor=0, paroxysmal_sweats=0, anxiety=0,
            agitation=0, tactile_disturbances=0, auditory_disturbances=0,
            visual_disturbances=0, headache=0, orientation=0):
    def v(x): return x[0] if isinstance(x,(list,tuple)) else x
    return (v(nausea_vomiting)+v(tremor)+v(paroxysmal_sweats)+v(anxiety)+
            v(agitation)+v(tactile_disturbances)+v(auditory_disturbances)+
            v(visual_disturbances)+v(headache)+v(orientation))
