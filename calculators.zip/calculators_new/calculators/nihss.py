
def compute_nihss_score(input_parameters):
    score = sum(input_parameters.values())
    return {"score": float(score)}
