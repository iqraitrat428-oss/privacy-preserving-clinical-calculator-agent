import age_conversion

param_full_name = {
    "age": "age",
    "gcs": ("Glasgow Coma Scale score", None),
    "altered_mental_status": ("altered mental status", None),
    "loss_of_consciousness": ("loss of consciousness", None),
    "vomiting": ("vomiting", None),
    "severe_headache": ("severe headache", None),
    "basilar_skull_fracture": ("signs of basilar skull fracture", None),
    "palpable_skull_fracture": ("palpable skull fracture", None),
    "scalp_hematoma": ("scalp hematoma (for <2 year olds)", None),
    "acting_normally": ("acting normally per parents (for <2 year olds)", None),
}


def pecarn_head_injury_explanation(input_parameters):
    explanation = """The PECARN Pediatric Head Injury Rule predicts clinically important traumatic brain injury (ciTBI).

For children <2 years:
- Very low risk (CT not needed): GCS=15, no AMS, no palpable skull fracture, no LOC, not severe scalp hematoma, acting normally per parent
- Intermediate risk: LOC, scalp hematoma (non-frontal), severe headache, or not acting normally — physician observation
- High risk (CT recommended): GCS <15, AMS, palpable skull fracture

For children ≥2 years:
- Very low risk: GCS=15, no AMS, no LOC, no vomiting, no severe headache, no basilar skull fracture signs
- Intermediate risk: LOC, vomiting, severe headache, severe mechanism — physician observation
- High risk (CT recommended): GCS <15, AMS, basilar skull fracture signs
"""
    age_exp, age = age_conversion.age_conversion_explanation(input_parameters["age"])
    explanation += age_exp

    gcs = input_parameters.get("gcs", 15)
    gcs = gcs[0] if isinstance(gcs,(list,tuple)) else gcs
    ams = input_parameters.get("altered_mental_status", False)
    loc = input_parameters.get("loss_of_consciousness", False)
    vomiting = input_parameters.get("vomiting", False)
    severe_ha = input_parameters.get("severe_headache", False)
    basilar = input_parameters.get("basilar_skull_fracture", False)
    palpable = input_parameters.get("palpable_skull_fracture", False)
    scalp = input_parameters.get("scalp_hematoma", False)
    acting = input_parameters.get("acting_normally", True)

    # Risk = 0 (very low), 1 (intermediate/observe), 2 (CT recommended)
    if gcs < 15 or ams or palpable or basilar:
        risk = 2
        label = "High risk — CT scan recommended"
    elif loc or vomiting or severe_ha or (age < 2 and scalp) or (age < 2 and not acting):
        risk = 1
        label = "Intermediate risk — physician observation vs CT"
    else:
        risk = 0
        label = "Very low risk — CT generally not indicated"

    explanation += f"\nBased on the PECARN criteria: {label} (Risk level: {risk}).\n"
    explanation += f"The PECARN risk classification is {risk} (0=very low, 1=intermediate, 2=high)."
    return {"Explanation": explanation, "Answer": risk}


def pecarn_head_injury(age, gcs=15, altered_mental_status=False, loss_of_consciousness=False,
                       vomiting=False, severe_headache=False, basilar_skull_fracture=False,
                       palpable_skull_fracture=False, scalp_hematoma=False, acting_normally=True):
    age = age_conversion.age_conversion(age)
    gcs = gcs[0] if isinstance(gcs,(list,tuple)) else gcs
    if gcs < 15 or altered_mental_status or palpable_skull_fracture or basilar_skull_fracture:
        return 2
    elif loss_of_consciousness or vomiting or severe_headache or (age < 2 and scalp_hematoma) or (age < 2 and not acting_normally):
        return 1
    return 0
