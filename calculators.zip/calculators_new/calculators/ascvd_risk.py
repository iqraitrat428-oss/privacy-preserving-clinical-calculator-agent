import math
import age_conversion

param_full_name = {
    "age": "age", "sex": "sex", "race": "race",
    "total_cholesterol": ("total cholesterol", None),
    "hdl_cholesterol": ("HDL cholesterol", None),
    "systolic_bp": ("systolic blood pressure", None),
    "bp_treatment": ("blood pressure treatment", None),
    "smoker": ("current smoker", None),
    "diabetes": ("diabetes", None),
}


def ascvd_risk_explanation(input_parameters):
    explanation = """The ASCVD (Atherosclerotic Cardiovascular Disease) 10-Year Risk uses the 2013 Pooled Cohort Equations.
The formula depends on sex and race (White Male, White Female, African American Male, African American Female).
Inputs: age, total cholesterol (mg/dL), HDL cholesterol (mg/dL), systolic BP (mm Hg), BP treatment (Yes/No), smoker (Yes/No), diabetes (Yes/No).
"""
    age = age_conversion.age_conversion(input_parameters["age"])
    sex = input_parameters["sex"].lower()
    race = input_parameters.get("race", "white").lower()
    tc = input_parameters["total_cholesterol"][0]
    hdl = input_parameters["hdl_cholesterol"][0]
    sbp = input_parameters["systolic_bp"][0]
    bpt = input_parameters.get("bp_treatment", False)
    smk = input_parameters.get("smoker", False)
    diab = input_parameters.get("diabetes", False)

    la = math.log(age); lc = math.log(tc); lh = math.log(hdl); ls = math.log(sbp)

    if sex == "male" and "african" not in race:
        IndX = (la*12.344 + lc*11.853 + la*lc*(-2.664) + lh*(-7.990) + la*lh*1.769 +
                ls*(1.764 if bpt else 1.764) + (1 if smk else 0)*7.837 +
                la*(1 if smk else 0)*(-1.795) + (1 if diab else 0)*0.661 - 61.18)
        base = 0.9144
    elif sex == "female" and "african" not in race:
        IndX = (la*(-7.574) + lc*17.1141 + la*lc*(-0.940) + lh*(-18.920) + la*lh*4.475 +
                ls*(29.291 if bpt else 27.819) + la*ls*(-6.087 if bpt else -6.087) +
                (1 if smk else 0)*0.661 + (1 if diab else 0)*0.661 - 29.799)
        base = 0.9665
    elif sex == "male":
        IndX = (la*2.469 + lc*0.302 + lh*(-0.307) +
                ls*(1.916 if bpt else 1.809) + (1 if smk else 0)*0.549 +
                (1 if diab else 0)*0.645 + 19.540 - 29.799)
        base = 0.8954
    else:
        IndX = (la*17.1141 + lc*0.940 + lh*(-18.920) + la*lh*4.475 +
                ls*(29.291 if bpt else 27.819) + la*ls*(-6.432 if bpt else -6.087) +
                (1 if smk else 0)*0.874 + (1 if diab else 0)*0.874 - 86.608)
        base = 0.9533

    risk = round((1 - base**math.exp(IndX)) * 100, 2)
    risk = max(0, min(100, risk))
    explanation += f"\nUsing the Pooled Cohort Equation for {sex} ({race}), the 10-year ASCVD risk is {risk}%."
    return {"Explanation": explanation, "Answer": risk}


def ascvd_risk(age, sex, total_cholesterol, hdl_cholesterol, systolic_bp,
               race="white", bp_treatment=False, smoker=False, diabetes=False):
    age = age_conversion.age_conversion(age)
    tc = total_cholesterol[0] if isinstance(total_cholesterol, (list,tuple)) else total_cholesterol
    hdl = hdl_cholesterol[0] if isinstance(hdl_cholesterol, (list,tuple)) else hdl_cholesterol
    sbp = systolic_bp[0] if isinstance(systolic_bp, (list,tuple)) else systolic_bp
    la = math.log(age); lc = math.log(tc); lh = math.log(hdl); ls = math.log(sbp)
    s = sex.lower(); r = str(race).lower()
    if s == "male" and "african" not in r:
        IndX = la*12.344+lc*11.853+la*lc*(-2.664)+lh*(-7.990)+la*lh*1.769+ls*1.764+(1 if smoker else 0)*7.837+la*(1 if smoker else 0)*(-1.795)+(1 if diabetes else 0)*0.661-61.18
        base = 0.9144
    elif s == "female" and "african" not in r:
        IndX = la*(-7.574)+lc*17.1141+la*lc*(-0.940)+lh*(-18.920)+la*lh*4.475+ls*(29.291 if bp_treatment else 27.819)+la*ls*(-6.087)+(1 if smoker else 0)*0.661+(1 if diabetes else 0)*0.661-29.799
        base = 0.9665
    elif s == "male":
        IndX = la*2.469+lc*0.302+lh*(-0.307)+ls*(1.916 if bp_treatment else 1.809)+(1 if smoker else 0)*0.549+(1 if diabetes else 0)*0.645+19.540-29.799
        base = 0.8954
    else:
        IndX = la*17.1141+lc*0.940+lh*(-18.920)+la*lh*4.475+ls*(29.291 if bp_treatment else 27.819)+la*ls*(-6.432)+(1 if smoker else 0)*0.874+(1 if diabetes else 0)*0.874-86.608
        base = 0.9533
    return round(max(0, min(100, (1 - base**math.exp(IndX))*100)), 2)
