import age_conversion

param_full_name = {
    "age": "age",
    "heart_rate": ("heart rate", None),
    "systolic_bp": ("systolic blood pressure", None),
    "creatinine": ("creatinine", None),
    "killip_class": "Killip class",
    "cardiac_arrest": ("cardiac arrest at admission", 43),
    "st_deviation": ("ST-segment deviation on ECG", 30),
    "elevated_enzymes": ("elevated cardiac enzymes/markers", 15),
}

killip_points = {1: 0, 2: 20, 3: 39, 4: 59}


def grace_acs_explanation(input_parameters):
    explanation = """The GRACE ACS Risk Score predicts in-hospital mortality for ACS.

Components:
- Age (years): <30=0, 30-39=8, 40-49=25, 50-59=41, 60-69=58, 70-79=75, 80-89=91, ≥90=100
- Heart rate (bpm): <50=0, 50-69=3, 70-89=9, 90-109=15, 110-149=24, 150-199=38, ≥200=46
- Systolic BP: ≥200=0, 160-199=10, 140-159=24, 120-139=34, 100-119=43, 80-99=53, <80=58
- Creatinine (mg/dL): 0-0.39=1, 0.4-0.79=4, 0.8-1.19=7, 1.2-1.59=10, 1.6-1.99=13, 2-3.99=21, ≥4=28
- Killip class: I=0, II=20, III=39, IV=59
- Cardiac arrest at admission: Yes=+43
- ST-segment deviation on ECG: Yes=+30
- Elevated cardiac enzymes: Yes=+15
"""
    explanation += "\nThe patient's current GRACE score is 0.\n"
    score = 0

    age_exp, age = age_conversion.age_conversion_explanation(input_parameters["age"])
    explanation += age_exp
    age_pts = (0 if age<30 else 8 if age<40 else 25 if age<50 else 41 if age<60
               else 58 if age<70 else 75 if age<80 else 91)
    explanation += f"Age {age} adds {age_pts} points, making the total {score} + {age_pts} = {score+age_pts}.\n"
    score += age_pts

    hr = input_parameters["heart_rate"][0] if isinstance(input_parameters["heart_rate"],(list,tuple)) else input_parameters["heart_rate"]
    hr_pts = (0 if hr<50 else 3 if hr<70 else 9 if hr<90 else 15 if hr<110 else 24 if hr<150 else 38 if hr<200 else 46)
    explanation += f"Heart rate {hr} bpm adds {hr_pts} points, making the total {score} + {hr_pts} = {score+hr_pts}.\n"
    score += hr_pts

    sbp = input_parameters["systolic_bp"][0] if isinstance(input_parameters["systolic_bp"],(list,tuple)) else input_parameters["systolic_bp"]
    sbp_pts = (58 if sbp<80 else 53 if sbp<100 else 43 if sbp<120 else 34 if sbp<140 else 24 if sbp<160 else 10 if sbp<200 else 0)
    explanation += f"SBP {sbp} mmHg adds {sbp_pts} points, making the total {score} + {sbp_pts} = {score+sbp_pts}.\n"
    score += sbp_pts

    cr = input_parameters["creatinine"][0] if isinstance(input_parameters["creatinine"],(list,tuple)) else input_parameters["creatinine"]
    cr_pts = (1 if cr<0.4 else 4 if cr<0.8 else 7 if cr<1.2 else 10 if cr<1.6 else 13 if cr<2.0 else 21 if cr<4.0 else 28)
    explanation += f"Creatinine {cr} mg/dL adds {cr_pts} points, making the total {score} + {cr_pts} = {score+cr_pts}.\n"
    score += cr_pts

    killip = input_parameters.get("killip_class", 1)
    killip = killip[0] if isinstance(killip,(list,tuple)) else killip
    k_pts = killip_points.get(int(killip), 0)
    explanation += f"Killip class {killip} adds {k_pts} points, making the total {score} + {k_pts} = {score+k_pts}.\n"
    score += k_pts

    if input_parameters.get("cardiac_arrest", False):
        explanation += f"Cardiac arrest at admission: +43 points, making the total {score} + 43 = {score+43}.\n"
        score += 43
    if input_parameters.get("st_deviation", False):
        explanation += f"ST-segment deviation: +30 points, making the total {score} + 30 = {score+30}.\n"
        score += 30
    if input_parameters.get("elevated_enzymes", False):
        explanation += f"Elevated cardiac enzymes: +15 points, making the total {score} + 15 = {score+15}.\n"
        score += 15

    explanation += f"The final GRACE ACS score is {score}."
    return {"Explanation": explanation, "Answer": score}


def grace_acs(age, heart_rate, systolic_bp, creatinine, killip_class=1,
              cardiac_arrest=False, st_deviation=False, elevated_enzymes=False):
    score = 0
    age = age_conversion.age_conversion(age)
    score += (0 if age<30 else 8 if age<40 else 25 if age<50 else 41 if age<60 else 58 if age<70 else 75 if age<80 else 91)
    hr = heart_rate[0] if isinstance(heart_rate,(list,tuple)) else heart_rate
    score += (0 if hr<50 else 3 if hr<70 else 9 if hr<90 else 15 if hr<110 else 24 if hr<150 else 38 if hr<200 else 46)
    sbp = systolic_bp[0] if isinstance(systolic_bp,(list,tuple)) else systolic_bp
    score += (58 if sbp<80 else 53 if sbp<100 else 43 if sbp<120 else 34 if sbp<140 else 24 if sbp<160 else 10 if sbp<200 else 0)
    cr = creatinine[0] if isinstance(creatinine,(list,tuple)) else creatinine
    score += (1 if cr<0.4 else 4 if cr<0.8 else 7 if cr<1.2 else 10 if cr<1.6 else 13 if cr<2.0 else 21 if cr<4.0 else 28)
    killip = killip_class[0] if isinstance(killip_class,(list,tuple)) else killip_class
    score += killip_points.get(int(killip), 0)
    if cardiac_arrest: score += 43
    if st_deviation: score += 30
    if elevated_enzymes: score += 15
    return score
