def calculate(**kwargs):
    """
    Safe BMI calculator
    """

    weight = kwargs.get("weight", 70)
    height = kwargs.get("height", 1.7)

    try:
        bmi = weight / (height ** 2)
        return {"bmi": round(bmi, 2)}
    except:
        return {"bmi": 0}

def bmi_calculator_explanation(input_parameters):
    weight = input_parameters.get('weight', [70, 'kg'])
    height = input_parameters.get('height', [170, 'cm'])
    w = weight[0] if isinstance(weight, (list,tuple)) else weight
    h = height[0] if isinstance(height, (list,tuple)) else height
    # convert height to meters if cm
    h_unit = weight[1] if isinstance(height, (list,tuple)) and len(height)>1 else 'cm'
    h_unit = height[1] if isinstance(height,(list,tuple)) and len(height)>1 else 'cm'
    if h_unit == 'cm': h = h/100
    elif h_unit == 'in': h = h * 0.0254
    bmi = round(w / (h**2), 2)
    exp = f"BMI = weight / height^2 = {w} kg / ({h} m)^2 = {bmi} kg/m^2"
    return {"Explanation": exp, "Answer": bmi}
