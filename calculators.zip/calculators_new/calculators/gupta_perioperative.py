import math, age_conversion

param_full_name = {
    "age": "age",
    "asa_class": "ASA physical status class",
    "functional_status": "functional status/dependency",
    "creatinine": ("creatinine", None),
    "surgery_type": "surgery type",
}

asa_coeff = {1: 0, 2: 0.61, 3: 1.22, 4: 1.83, 5: 2.44}
functional_coeff = {"independent": 0, "partially dependent": 0.61, "totally dependent": 1.22}
surgery_coeff = {"other": 0, "anorectal": -0.16, "aortic": 1.60, "bariatric": -0.25,
                 "brain": 1.15, "breast": -1.61, "cardiac": 1.06, "gallbladder": -0.01,
                 "hepatic": 1.35, "hernia": -0.20, "intestinal": 0.45, "neck": 0.07,
                 "obstetric/gynecologic": 0.56, "orthopedic/back": 0.20, "peripheral vascular": 0.86,
                 "rectal": 0.86, "renal": 0.54, "skin": -0.53, "spine": 0.29,
                 "stomach/esophageal": 0.71, "thoracic": 1.06, "vein": -0.19, "urologic": 0.02}


def gupta_perioperative_explanation(input_parameters):
    explanation = """The Gupta Perioperative MICA (Myocardial Infarction or Cardiac Arrest) Score.
Uses logistic regression to estimate risk of perioperative MICA.
Inputs: Age, ASA class, functional status, creatinine, surgery type.
"""
    age = age_conversion.age_conversion(input_parameters["age"])
    asa = int(input_parameters.get("asa_class", [1])[0] if isinstance(input_parameters.get("asa_class"), (list,tuple)) else input_parameters.get("asa_class", 1))
    func = str(input_parameters.get("functional_status", "independent")).lower()
    cr = input_parameters.get("creatinine", [1.0, "mg/dL"])
    cr_val = cr[0] if isinstance(cr, (list,tuple)) else cr
    surg = str(input_parameters.get("surgery_type", "other")).lower()

    coeff = (-5.76 + 0.02*age + asa_coeff.get(asa, 0) +
             functional_coeff.get(func, 0) + 0.16*cr_val +
             surgery_coeff.get(surg, 0))
    risk = round(100 * math.exp(coeff) / (1 + math.exp(coeff)), 2)

    explanation += f"\nUsing logistic regression model:\n"
    explanation += f"Age coefficient: {0.02}*{age} = {round(0.02*age,4)}\n"
    explanation += f"ASA class {asa} coefficient: {asa_coeff.get(asa,0)}\n"
    explanation += f"Functional status '{func}' coefficient: {functional_coeff.get(func,0)}\n"
    explanation += f"Creatinine {cr_val} coefficient: {round(0.16*cr_val,4)}\n"
    explanation += f"Surgery type '{surg}' coefficient: {surgery_coeff.get(surg,0)}\n"
    explanation += f"Intercept: -5.76\n"
    explanation += f"The estimated perioperative MICA risk is {risk}%."
    return {"Explanation": explanation, "Answer": risk}


def gupta_perioperative(age, asa_class=1, functional_status="independent",
                         creatinine=None, surgery_type="other"):
    age = age_conversion.age_conversion(age)
    asa = int(asa_class[0] if isinstance(asa_class,(list,tuple)) else asa_class)
    func = str(functional_status).lower()
    cr = creatinine[0] if isinstance(creatinine,(list,tuple)) else (creatinine or 1.0)
    surg = str(surgery_type).lower()
    coeff = (-5.76 + 0.02*age + asa_coeff.get(asa,0) +
             functional_coeff.get(func,0) + 0.16*cr + surgery_coeff.get(surg,0))
    return round(100*math.exp(coeff)/(1+math.exp(coeff)), 2)
