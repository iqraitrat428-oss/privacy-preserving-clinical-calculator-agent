import age_conversion

param_full_name = {
    "age": "age",
    "spo2": ("preoperative SpO2 < 96%", None),
    "respiratory_infection": ("respiratory infection in the last month", 17),
    "preoperative_anemia": ("preoperative anemia (Hct < 30%)", 11),
    "surgical_incision": "surgical incision",
    "duration": "duration of surgery",
    "emergency": ("emergency procedure", 8),
}

surgical_incision_points = {"peripheral": 0, "upper abdominal": 15, "intrathoracic": 24}
duration_points = {"less than 2 hours": 0, "2-3 hours": 16, "more than 3 hours": 23}


def ariscat_score_explanation(input_parameters):
    explanation = """The criteria for the ARISCAT Score are listed below:

1. Age: ≤50 = 0 points, 51-80 = +3 points, >80 = +16 points
2. Preoperative SpO2: ≥96% = 0 points, 91-95% = +8 points, ≤90% = +24 points
3. Respiratory infection in the last month: No = 0, Yes = +17 points
4. Preoperative anemia (Hct < 30%): No = 0, Yes = +11 points
5. Surgical incision: Peripheral = 0, Upper abdominal = +15, Intrathoracic = +24
6. Duration of surgery: < 2 hours = 0, 2-3 hours = +16, > 3 hours = +23
7. Emergency procedure: No = 0, Yes = +8 points

The total ARISCAT Score is calculated by summing the points for each criterion.
"""
    explanation += "\nThe patient's current ARISCAT score is 0.\n"
    score = 0

    age_exp, age = age_conversion.age_conversion_explanation(input_parameters["age"])
    explanation += age_exp
    if age <= 50:
        explanation += f"Because the patient's age is ≤50, we add 0 points, keeping the total at {score}.\n"
    elif age <= 80:
        explanation += f"Because the patient's age is between 51 and 80, we add 3 points, making the total {score} + 3 = {score + 3}.\n"
        score += 3
    else:
        explanation += f"Because the patient's age is >80, we add 16 points, making the total {score} + 16 = {score + 16}.\n"
        score += 16

    spo2 = input_parameters.get("spo2", [99, "%"])[0]
    explanation += f"The patient's preoperative SpO2 is {spo2}%. "
    if spo2 >= 96:
        explanation += f"Because SpO2 ≥ 96%, we add 0 points, keeping the total at {score}.\n"
    elif spo2 >= 91:
        explanation += f"Because SpO2 is between 91-95%, we add 8 points, making the total {score} + 8 = {score + 8}.\n"
        score += 8
    else:
        explanation += f"Because SpO2 ≤ 90%, we add 24 points, making the total {score} + 24 = {score + 24}.\n"
        score += 24

    if input_parameters.get("respiratory_infection", False):
        explanation += f"The patient has a respiratory infection in the last month, so we add 17 points, making the total {score} + 17 = {score + 17}.\n"
        score += 17
    else:
        explanation += f"The patient does not have a respiratory infection, so we add 0 points, keeping the total at {score}.\n"

    if input_parameters.get("preoperative_anemia", False):
        explanation += f"The patient has preoperative anemia, so we add 11 points, making the total {score} + 11 = {score + 11}.\n"
        score += 11
    else:
        explanation += f"The patient does not have preoperative anemia, so we add 0 points, keeping the total at {score}.\n"

    incision = input_parameters.get("surgical_incision", "peripheral").lower()
    pts = surgical_incision_points.get(incision, 0)
    explanation += f"The surgical incision is '{incision}', so we add {pts} points, making the total {score} + {pts} = {score + pts}.\n"
    score += pts

    dur = input_parameters.get("duration", "less than 2 hours").lower()
    pts = duration_points.get(dur, 0)
    explanation += f"The duration of surgery is '{dur}', so we add {pts} points, making the total {score} + {pts} = {score + pts}.\n"
    score += pts

    if input_parameters.get("emergency", False):
        explanation += f"The procedure is an emergency, so we add 8 points, making the total {score} + 8 = {score + 8}.\n"
        score += 8
    else:
        explanation += f"The procedure is not an emergency, so we add 0 points, keeping the total at {score}.\n"

    explanation += f"The final ARISCAT score is {score}."
    return {"Explanation": explanation, "Answer": score}


def ariscat_score(age, spo2=None, respiratory_infection=False, preoperative_anemia=False,
                  surgical_incision="peripheral", duration="less than 2 hours", emergency=False):
    score = 0
    age = age_conversion.age_conversion(age)
    if age <= 50: pass
    elif age <= 80: score += 3
    else: score += 16

    spo2_val = spo2[0] if isinstance(spo2, (list, tuple)) else (spo2 if spo2 is not None else 99)
    if spo2_val >= 96: pass
    elif spo2_val >= 91: score += 8
    else: score += 24

    if respiratory_infection: score += 17
    if preoperative_anemia: score += 11
    score += surgical_incision_points.get(str(surgical_incision).lower(), 0)
    score += duration_points.get(str(duration).lower(), 0)
    if emergency: score += 8
    return score
