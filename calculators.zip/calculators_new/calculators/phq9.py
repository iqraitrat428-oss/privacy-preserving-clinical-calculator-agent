param_full_name = {
    "little_interest": ("little interest or pleasure in doing things", None),
    "feeling_down": ("feeling down, depressed, or hopeless", None),
    "sleep_trouble": ("trouble falling or staying asleep, or sleeping too much", None),
    "little_energy": ("feeling tired or having little energy", None),
    "poor_appetite": ("poor appetite or overeating", None),
    "feeling_bad": ("feeling bad about yourself or that you are a failure", None),
    "trouble_concentrating": ("trouble concentrating on things", None),
    "moving_slowly": ("moving or speaking so slowly that other people could have noticed, or being fidgety/restless", None),
    "thoughts_of_self_harm": ("thoughts that you would be better off dead or of hurting yourself", None),
}

freq_map = {"not at all": 0, "several days": 1, "more than half the days": 2, "nearly every day": 3}


def phq9_explanation(input_parameters):
    explanation = """The PHQ-9 (Patient Health Questionnaire-9):

Over the last 2 weeks, how often have you been bothered by:
1. Little interest or pleasure in doing things (0-3)
2. Feeling down, depressed, or hopeless (0-3)
3. Trouble falling or staying asleep (0-3)
4. Feeling tired or having little energy (0-3)
5. Poor appetite or overeating (0-3)
6. Feeling bad about yourself (0-3)
7. Trouble concentrating on things (0-3)
8. Moving or speaking slowly / being fidgety (0-3)
9. Thoughts of self-harm (0-3)

Scoring: Not at all=0, Several days=1, More than half=2, Nearly every day=3
Total 1-4: Minimal, 5-9: Mild, 10-14: Moderate, 15-19: Moderately severe, 20-27: Severe
"""
    explanation += "\nThe patient's current PHQ-9 score is 0.\n"
    score = 0
    for param, label in param_full_name.items():
        val = input_parameters.get(param, 0)
        val = val[0] if isinstance(val,(list,tuple)) else val
        if isinstance(val, str): val = freq_map.get(val.lower(), 0)
        explanation += f"{label[0].capitalize()}: {val} points, making the total {score} + {val} = {score+val}.\n"
        score += val
    explanation += f"The final PHQ-9 score is {score}."
    return {"Explanation": explanation, "Answer": score}


def phq9(little_interest=0, feeling_down=0, sleep_trouble=0, little_energy=0,
         poor_appetite=0, feeling_bad=0, trouble_concentrating=0,
         moving_slowly=0, thoughts_of_self_harm=0):
    def v(x):
        x = x[0] if isinstance(x,(list,tuple)) else x
        if isinstance(x,str): return freq_map.get(x.lower(),0)
        return x
    return sum(v(i) for i in [little_interest,feeling_down,sleep_trouble,little_energy,
                                poor_appetite,feeling_bad,trouble_concentrating,
                                moving_slowly,thoughts_of_self_harm])
