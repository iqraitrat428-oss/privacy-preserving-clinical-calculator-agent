from datetime import datetime, timedelta

param_full_name = {
    "last_menstrual_period": "last menstrual period date",
    "cycle_length": ("menstrual cycle length", None),
    "gestational_age_weeks": ("gestational age (weeks)", None),
    "gestational_age_days": ("gestational age (days)", None),
    "reference_date": "reference date",
}


def pregnancy_due_dates_explanation(input_parameters):
    explanation = """Pregnancy Due Dates Calculator (Naegele's Rule):

Estimated Due Date (EDD) = Last Menstrual Period (LMP) + 280 days (40 weeks)
Adjusted for cycle length: EDD = LMP + 280 + (cycle_length - 28) days

If gestational age is provided instead of LMP:
LMP = Reference Date - Gestational Age
EDD = LMP + 280 days (adjusted for cycle length)
"""
    cycle = input_parameters.get("cycle_length", [28])[0] if isinstance(input_parameters.get("cycle_length"), (list,tuple)) else input_parameters.get("cycle_length", 28)
    extra = int(cycle) - 28

    if "last_menstrual_period" in input_parameters:
        lmp_str = input_parameters["last_menstrual_period"]
        try:
            lmp = datetime.strptime(lmp_str, "%m/%d/%Y")
        except:
            lmp = datetime.strptime(lmp_str, "%Y-%m-%d")
        edd = lmp + timedelta(days=280+extra)
        explanation += f"\nLMP: {lmp.strftime('%m/%d/%Y')}\n"
        explanation += f"Cycle length: {cycle} days (adjustment: {extra:+d} days)\n"
        explanation += f"EDD = LMP + {280+extra} days = {edd.strftime('%m/%d/%Y')}\n"
        explanation += f"The estimated due date is {edd.strftime('%m/%d/%Y')} ({280+extra} days from LMP)."
        return {"Explanation": explanation, "Answer": edd.strftime("%m/%d/%Y")}

    elif "gestational_age_weeks" in input_parameters:
        weeks = int(input_parameters["gestational_age_weeks"][0] if isinstance(input_parameters["gestational_age_weeks"],(list,tuple)) else input_parameters["gestational_age_weeks"])
        days = int(input_parameters.get("gestational_age_days", 0))
        days = days[0] if isinstance(days,(list,tuple)) else days
        total_days_pregnant = weeks*7 + int(days)
        ref_str = input_parameters.get("reference_date", datetime.now().strftime("%m/%d/%Y"))
        try:
            ref = datetime.strptime(ref_str, "%m/%d/%Y")
        except:
            ref = datetime.strptime(ref_str, "%Y-%m-%d")
        lmp = ref - timedelta(days=total_days_pregnant)
        edd = lmp + timedelta(days=280+extra)
        explanation += f"\nGestational age: {weeks}w {int(days)}d = {total_days_pregnant} days pregnant\n"
        explanation += f"Reference date: {ref.strftime('%m/%d/%Y')}\n"
        explanation += f"LMP = {ref.strftime('%m/%d/%Y')} - {total_days_pregnant} days = {lmp.strftime('%m/%d/%Y')}\n"
        explanation += f"EDD = LMP + {280+extra} days = {edd.strftime('%m/%d/%Y')}\n"
        explanation += f"The estimated due date is {edd.strftime('%m/%d/%Y')}."
        return {"Explanation": explanation, "Answer": edd.strftime("%m/%d/%Y")}

    return {"Explanation": "Insufficient data to calculate due date.", "Answer": None}


def pregnancy_due_dates(last_menstrual_period=None, cycle_length=28,
                         gestational_age_weeks=None, gestational_age_days=0,
                         reference_date=None):
    cycle = cycle_length[0] if isinstance(cycle_length,(list,tuple)) else cycle_length
    extra = int(cycle) - 28
    if last_menstrual_period:
        lmp_str = last_menstrual_period[0] if isinstance(last_menstrual_period,(list,tuple)) else last_menstrual_period
        try: lmp = datetime.strptime(lmp_str, "%m/%d/%Y")
        except: lmp = datetime.strptime(lmp_str, "%Y-%m-%d")
        return (lmp + timedelta(days=280+extra)).strftime("%m/%d/%Y")
    elif gestational_age_weeks is not None:
        weeks = int(gestational_age_weeks[0] if isinstance(gestational_age_weeks,(list,tuple)) else gestational_age_weeks)
        days = int(gestational_age_days[0] if isinstance(gestational_age_days,(list,tuple)) else gestational_age_days)
        ref_str = reference_date or datetime.now().strftime("%m/%d/%Y")
        ref_str = ref_str[0] if isinstance(ref_str,(list,tuple)) else ref_str
        try: ref = datetime.strptime(ref_str, "%m/%d/%Y")
        except: ref = datetime.strptime(ref_str, "%Y-%m-%d")
        lmp = ref - timedelta(days=weeks*7+days)
        return (lmp + timedelta(days=280+extra)).strftime("%m/%d/%Y")
    return None
