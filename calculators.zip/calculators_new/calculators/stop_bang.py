import age_conversion

param_full_name = {
    "snoring": ("do you snore loudly", 1),
    "tired": ("do you often feel tired or sleepy during the daytime", 1),
    "observed_apnea": ("has anyone observed you stop breathing during sleep", 1),
    "bp_treatment": ("do you have or are you being treated for high blood pressure", 1),
    "bmi": "bmi",
    "age": "age",
    "neck_circumference": "neck circumference",
    "sex": "sex",
}


def stop_bang_explanation(input_parameters):
    explanation = """The STOP-BANG Score criteria are:
S - Snoring loudly: Yes = +1
T - Tired/sleepy during the day: Yes = +1
O - Observed apnea during sleep: Yes = +1
P - Pressure (hypertension treated): Yes = +1
B - BMI > 35: Yes = +1
A - Age > 50: Yes = +1
N - Neck circumference > 40 cm: Yes = +1
G - Gender = Male: Yes = +1

Score 0-2: Low risk, 3-4: Intermediate risk, 5-8: High risk.
"""
    explanation += "\nThe patient's current STOP-BANG score is 0.\n"
    score = 0

    if input_parameters.get("snoring", False):
        explanation += f"The patient snores loudly, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"The patient does not snore loudly, so we add 0 points, keeping the total at {score}.\n"

    if input_parameters.get("tired", False):
        explanation += f"The patient is often tired/sleepy, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"The patient is not often tired, so we add 0 points, keeping the total at {score}.\n"

    if input_parameters.get("observed_apnea", False):
        explanation += f"Observed apnea is reported, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"No observed apnea, so we add 0 points, keeping the total at {score}.\n"

    if input_parameters.get("bp_treatment", False):
        explanation += f"The patient is treated for hypertension, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"The patient does not have hypertension, so we add 0 points, keeping the total at {score}.\n"

    bmi_val = input_parameters.get("bmi", [24, "kg/m^2"])
    bmi = bmi_val[0] if isinstance(bmi_val, (list,tuple)) else bmi_val
    if bmi > 35:
        explanation += f"BMI is {bmi} kg/m^2 > 35, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"BMI is {bmi} kg/m^2 ≤ 35, so we add 0 points, keeping the total at {score}.\n"

    age_exp, age = age_conversion.age_conversion_explanation(input_parameters["age"])
    explanation += age_exp
    if age > 50:
        explanation += f"Age > 50, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"Age ≤ 50, so we add 0 points, keeping the total at {score}.\n"

    neck = input_parameters.get("neck_circumference", [38, "cm"])
    neck_val = neck[0] if isinstance(neck, (list,tuple)) else neck
    if neck_val > 40:
        explanation += f"Neck circumference {neck_val} cm > 40, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"Neck circumference {neck_val} cm ≤ 40, so we add 0 points, keeping the total at {score}.\n"

    sex = input_parameters.get("sex", "female").lower()
    if sex == "male":
        explanation += f"The patient is male, so we add 1 point, making the total {score} + 1 = {score+1}.\n"
        score += 1
    else:
        explanation += f"The patient is female, so we add 0 points, keeping the total at {score}.\n"

    explanation += f"The final STOP-BANG score is {score}."
    return {"Explanation": explanation, "Answer": score}


def stop_bang(age, sex, bmi=None, neck_circumference=None,
              snoring=False, tired=False, observed_apnea=False, bp_treatment=False):
    score = 0
    if snoring: score += 1
    if tired: score += 1
    if observed_apnea: score += 1
    if bp_treatment: score += 1
    bmi_val = bmi[0] if isinstance(bmi, (list,tuple)) else (bmi or 24)
    if bmi_val > 35: score += 1
    age = age_conversion.age_conversion(age)
    if age > 50: score += 1
    neck_val = neck_circumference[0] if isinstance(neck_circumference, (list,tuple)) else (neck_circumference or 38)
    if neck_val > 40: score += 1
    if str(sex).lower() == "male": score += 1
    return score
