import json
import os
import random
import steroid_conversion_calculator
from datetime import datetime, timedelta
import importlib.util
import height_conversion
from rounding import round_number

#random.seed(42)


def random_date():

    month = random.randint(1, 12)

    year = random.randint(2000, 2024)

    if month in set([1, 3, 5, 7, 8, 10, 12]):
        day = random.randint(1, 31)
    elif month == 2:
        if month % 4 == 0:
            day = random.randint(1, 29)
        else:
            day = random.randint(1, 28)
    else:
        day = random.randint(1,30)

    return month, day, year

def estimated_date_calculator():
    data = {}

    cycle_length = random.randint(20, 30)

    month, day, year = random_date()

    date_obj = datetime(year, month, day)
    
    modified_date_string = date_obj.strftime("%m/%d/%Y")

    edd_note = f"The patient's last menstrual period was on {modified_date_string}. Her cycle length is {cycle_length} days."

    data = {"cycle_length": cycle_length, "menstrual_date": modified_date_string}

    return edd_note, data


def estimated_date_of_conception():
    data = {}

    cycle_length = random.randint(20, 30)

    month, day, year = random_date()

    date_obj = datetime(year, month, day)

    modified_date_string = date_obj.strftime("%m/%d/%Y")

    edc_note = f"The patient's last menstrual period was on {modified_date_string}."
    
    data = {"menstrual_date": modified_date_string}

    return edc_note, data


def estimated_gestational_age():
    data = {}


    month, day, year = random_date()

    week_to_add = random.randint(0, 37)
    days_to_add = random.randint(0, 6)

    date_obj = datetime(year, month, day)

    date_obj_str = date_obj.strftime("%m/%d/%Y")

    modified_date = date_obj + timedelta(weeks=week_to_add, days=days_to_add)

    modified_date_string = modified_date.strftime("%m/%d/%Y")

    ega_note = f"The patient's last menstrual period was on {date_obj_str}. Today's date is {modified_date_string}."
    
    data = {"current_date": modified_date_string, "menstrual_date": date_obj_str}

    return ega_note, data


def qt_interval_patient_notes_bazett():
    data = {}


    heart_rate = round(random.uniform(45, 180))

    qt_interval = round(random.uniform(200, 500))

    note = f"A patient has a heart rate of {heart_rate} bpm and a QT interval of {qt_interval} msec."

    data = {"heart_rate": [heart_rate, "beats per minute"], "qt_interval": [qt_interval, "msec"]}
    
    return note, data


def qt_interval_patient_notes_framingham():
    data = {}

    heart_rate = round(random.uniform(45, 180))

    qt_interval = round(random.uniform(200, 500))

    data = {"heart_rate": [heart_rate, "beats per minute"], "qt_interval": [qt_interval, "msec"]}
    
    return note, data


def qt_interval_patient_notes_fridericia():
    data = {}

    heart_rate = round(random.uniform(45, 180))

    qt_interval = round(random.uniform(200, 500))

    note = f"A patient has a heart rate of {heart_rate} bpm and a QT interval of {qt_interval} msec."

    data = {"heart_rate": [heart_rate, "beats per minute"], "qt_interval": [qt_interval, "msec"]}
    
    return note, data


def qt_interval_patient_notes_hodges():
    data = {}

    heart_rate = round(random.uniform(45, 180))

    qt_interval = round(random.uniform(200, 500))

    note = f"A patient has a heart rate of {heart_rate} bpm and a QT interval of {qt_interval} msec."

    data = {"heart_rate": [heart_rate, "beats per minute"], "qt_interval": [qt_interval, "msec"]}
    
    return note, data


def qt_interval_patient_notes_rautaharju():
    data = {}


    heart_rate = round(random.uniform(45, 180))

    qt_interval = round(random.uniform(200, 500))

    note = f"A patient has a heart rate of {heart_rate} bpm and a QT interval of {qt_interval} msec."

    data = {"heart_rate": [heart_rate, "beats per minute"], "qt_interval": [qt_interval, "msec"]}
    
    return note, data


def mme_conversion():
    data = {}
    
    mme_drugs = ["Codeine", "FentaNYL buccal", "HYDROcodone", "HYDROmorphone", "Methadone", "Morphine", 
                 "OxyCODONE", "OxyMORphone", "Tapentadol", "TraMADol"]
    

    num_instances = random.randint(1,3)

    drugs = random.sample(mme_drugs, num_instances)

    note = "A patient takes "

    data = {}

    for i in range(num_instances):

        num_doses = random.randint(1, 3)
        num_amount = round(random.randint(1, 3)) * 10

        key_name_dose = drugs[i] + " Dose"
        key_name_dose_per_day = drugs[i] + " Dose Per Day"

        if drugs[i] == "FentaNYL buccal":
            data[key_name_dose] = [num_amount , "µg"]
        else:
            data[key_name_dose] = [num_amount , "mg"]
        
        data[key_name_dose_per_day] = [num_doses, "per day"]

        add_s = 's'

        if num_doses == 1:
            add_s = ''

        if (num_instances == 2 or num_instances == 3) and i == len(drugs) - 1:
            note += f"and {num_amount} mg of {drugs[i]} {num_doses} time{add_s} a day."
        elif (num_instances == 1 and i == 0):
            note += f"{num_amount} mg of {drugs[i]} {num_doses} time{add_s} a day. "
        elif (num_instances == 3):
            note += f"{num_amount} mg of {drugs[i]} {num_doses} time{add_s} a day, "
        elif (num_instances == 2):
            note += f"{num_amount} mg of {drugs[i]} {num_doses} time{add_s} a day "

    return note, data

def steroid_conversion():
    data = {}

  
    steroid_names = ['Betamethasone IV', 'Cortisone PO', 'Dexamethasone IV', 'Dexamethasone PO', 'Hydrocortisone IV', 'Hydrocortisone PO',  'MethylPrednisoLONE IV', 'MethylPrednisoLONE PO', 'PredniSONE PO', 'PrednisoLONE PO', 'Triamcinolone IV']
    
    choices = random.sample(steroid_names, 2)

    random_value = round(random.uniform(0.6, 9), 2)

    data = {"input steroid": ['Betamethasone IV', random_value, "mg"], "target steroid": choices[0]}
    
    amount = round_number(steroid_conversion_calculator.compute_steroid_conversion(data))

    note = f"A patient has taken {amount} mg of {choices[0]}. "

    data = {"input steroid": [choices[0], round_number(amount), "mg"], "target steroid": choices[1]}

    return note, data

# Have the functions for generating the values. Just ask the LLM to compute the value. 

def target_weight():
    data = {}

    height_units = ["cm", "m", "in"]

    height_value = round(random.uniform(1.4, 2.0) , 2)

    height_unit = random.choice(height_units)

    if height_unit == "in":
        height_value = round(height_conversion.height_conversion_in([height_value, "m"]))
    elif height_unit == "cm":
        height_value = round(height_conversion.height_conversion_cm([height_value, "m"]))
    elif height_unit == "m":
        height_value = round(height_conversion.height_conversion([height_value, "m"]), 2)

    bmi = round(random.uniform(18, 25) , 1)

    note = f"Patient has a height of {height_value} {height_unit} and their target BMI is {bmi} kg/m^2."

    data = {"body_mass_index": [bmi, "kg/m^2"], "height": [height_value, height_unit]}
    
    return note, data


_script_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(_script_dir, "name_to_python.json")) as file:
    calc_info  = json.load(file)

problems = {}

calc_ids = ["11", "13", "24", "56", "57", "58", "59", "61", "49", "68", "69"]


calculator_id_to_name = {
                         "11": "qt_interval_patient_notes_bazett", 
                         "13": "estimated_date_calculator",
                         "24": "steroid_conversion", 
                         "56": "qt_interval_patient_notes_framingham",
                         "57": "qt_interval_patient_notes_fridericia",
                         "58": "qt_interval_patient_notes_hodges",
                         "59": "qt_interval_patient_notes_rautaharju",
                         "61": "target_weight",
                         "49": "mme_conversion",
                         "68": "estimated_date_of_conception",
                         "69": "estimated_gestational_age"
                        }


data = {}

for calc_id in calc_ids:

    calculator_name_formal = calc_info[calc_id]["calculator name"]

    data[calc_id] = {}

    for i in range(0, 100):

        function_name = calculator_id_to_name[calc_id]

        if function_name in globals() and callable(globals()[function_name]):
            note, data =  globals()[function_name]()

    
            key_name =  str(i + 1)
            
            spec = importlib.util.spec_from_file_location("my_module", calc_info[calc_id]["file path"])
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            function = getattr(module, calc_info[calc_id]["explanation function"])

            gt_result = function(data)

            data[calc_id][key_name] = {}
            data[calc_id][key_name]["explanation"] = gt_result["Explanation"]
            data[calc_id][key_name]["Ground Truth Answer"] = gt_result["Answer"]
            data[calc_id][key_name]["calculator name"] = calc_info[calc_id]["calculator name"]
            data[calc_id][key_name]["Patient Note"] = note
            data[calc_id][key_name]["data"] = data
            



print(data)

with open("synthetic_instances_train_2.json", "w") as file:
    json.dump(data, file, indent=4)



